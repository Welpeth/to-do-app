package com.example.todoapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.todoapp.TaskAdapter;
import com.example.todoapp.Task;
import com.example.todoapp.R;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Task> taskList;
    private TaskAdapter taskAdapter;
    private RecyclerView recyclerView;
    private EditText titleInput, descriptionInput;
    private Button addButton;

    private static final String PREFS_NAME = "task_prefs";
    private static final String TASK_LIST_KEY = "task_list";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializando lista de tarefas e o adaptador
        taskList = loadTasks(); // Carrega as tarefas do SharedPreferences
        taskAdapter = new TaskAdapter(taskList, this);

        // Configurando o RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(taskAdapter);

        // Configurando inputs e botões
        titleInput = findViewById(R.id.titleInput);
        descriptionInput = findViewById(R.id.descriptionInput);
        addButton = findViewById(R.id.addButton);

        // Adicionando comportamento ao botão de adicionar tarefa
        addButton.setOnClickListener(v -> {
            String title = titleInput.getText().toString();
            String description = descriptionInput.getText().toString();

            // Verifica se os campos estão preenchidos
            if (title.isEmpty() || description.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                // Obtendo a data e hora atual
                String currentDate = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());

                // Criando nova tarefa com status 'não concluída' (isCompleted = false)
                Task task = new Task(title, description, false, currentDate);

                // Adicionando tarefa à lista e notificando o adaptador
                taskList.add(task);
                taskAdapter.notifyDataSetChanged();

                // Salvando tarefas no SharedPreferences
                saveTasks();

                // Mostrando mensagem de sucesso
                Toast.makeText(this, "Task added", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void saveTasks() { // Mudou para public
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        Gson gson = new Gson();
        String json = gson.toJson(taskList);
        editor.putString(TASK_LIST_KEY, json);
        editor.apply(); // Salva as mudanças
    }

    private ArrayList<Task> loadTasks() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String json = sharedPreferences.getString(TASK_LIST_KEY, null);

        Gson gson = new Gson();
        Type type = new TypeToken<ArrayList<Task>>() {}.getType();
        return gson.fromJson(json, type); // Carrega as tarefas
    }
}
