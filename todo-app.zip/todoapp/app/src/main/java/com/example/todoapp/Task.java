package com.example.todoapp;

public class Task {
    private String title;
    private String description; // Adiciona a descrição
    private boolean isCompleted;
    private String dateCreated;

    public Task(String title, String description, boolean isCompleted, String dateCreated) {
        this.title = title;
        this.description = description; // Inicializa a descrição
        this.isCompleted = isCompleted;
        this.dateCreated = dateCreated;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() { // Método para obter a descrição
        return description;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    public void setCompleted(boolean completed) {
        isCompleted = completed;
    }

    public String getDateCreated() {
        return dateCreated;
    }
}
